#! /bin/bash

if [ -f "$TUNNEL_DIR/configure_job.sh" ]
  then source $TUNNEL_DIR/configure_job.sh
  else source $HPCTUNNELS_DIR/configure_job.sh
fi

# Load in user-specified configuration
if [ -f "$TUNNEL_DIR/user.sh" ]; then
    source $TUNNEL_DIR/user.sh
fi

if [ ! -d "$BROWSE_DIR" ]; then
  echo "BROWSE_DIR does not exist: $BROWSE_DIR"
  exit 1
fi

echo "Serving $BROWSE_DIR on $PROCESS_PORT"

# --directory / --bind require Python 3.7+; every login node this has
# been tested against ships something newer than that already.
python3 -m http.server "$PROCESS_PORT" --directory "$BROWSE_DIR" --bind 127.0.0.1
