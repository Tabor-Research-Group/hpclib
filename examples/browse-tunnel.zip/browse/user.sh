# What directory this tunnel serves. Override per-machine here, or
# per-invocation with `--env="BROWSE_DIR=/some/path"` on the CLI
# without touching this file at all.
export BROWSE_DIR="${BROWSE_DIR:-$HOME}"
